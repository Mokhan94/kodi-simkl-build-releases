from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .progress import InstallCancelled, create_progress


ADDON_ID = 'plugin.program.mokhan.updater'
BUILD_NAME = 'Kodi Simkl Build'
SETUP_NAME = 'Build Setup'
DEFAULT_VERSION = '0.1.0'
ALLOWED_ROOTS = ('addons', 'userdata', 'media', 'system')
PROTECTED_SETTINGS = (
    'userdata/addon_data/plugin.video.seren/settings.xml',
    'userdata/addon_data/plugin.video.themoviedb.helper/settings.xml',
    'userdata/addon_data/plugin.video.otaku.testing/settings.xml',
    'userdata/addon_data/script.trakt/settings.xml',
)
PROTECTED_PREFIXES = (
    'userdata/addon_data/plugin.program.mokhan.updater/',
    'userdata/addon_data/plugin.video.themoviedb.helper/database_',
)
PROTECTED_NAMES = ('passwords.xml', 'sources.xml', 'profiles.xml')
PROTECTED_EXTENSIONS = ('.db', '.sqlite', '.sqlite3', '.log', '.dmp')
RETIRED_ADDONS = ('script.trakt',)
REQUIRED_ACTIVATION = (
    'plugin.video.seren',
    'plugin.video.themoviedb.helper',
    'skin.arctic.horizon.2',
)
SKIN_DEPENDENCIES = (
    'script.skinshortcuts',
    'script.skinvariables',
    'script.texturemaker',
    'plugin.video.themoviedb.helper',
    'resource.images.weathericons.white',
    'resource.images.studios.coloured',
    'resource.font.robotocjksc',
    'skin.arctic.horizon.2',
)
OTAKU_INSTALL_ORDER = (
    'script.module.inputstreamhelper',
    'script.module.pyqrcode',
    'context.otaku.testing',
    'plugin.video.otaku.testing',
)


class UpdateError(Exception):
    pass


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[Mokhan Build Updater] {}'.format(message), level)


def kodi_path(path):
    return xbmcvfs.translatePath(path)


def version_key(value):
    return tuple(int(part) for part in re.findall(r'\d+', value or '0'))


def format_bytes(value):
    value = float(value or 0)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if value < 1024 or unit == 'GB':
            return '{:.1f} {}'.format(value, unit)
        value /= 1024


def normalize_relative(path):
    path = path.replace('\\', '/').lstrip('/')
    normalized = os.path.normpath(path).replace('\\', '/')
    if normalized in ('', '.') or normalized == '..' or normalized.startswith('../'):
        raise UpdateError('Unsafe archive path: {}'.format(path))
    if ':' in normalized.split('/')[0]:
        raise UpdateError('Unsafe archive path: {}'.format(path))
    return normalized


def is_protected(relative_path):
    lowered = relative_path.lower()
    if lowered in PROTECTED_SETTINGS:
        return True
    if lowered.startswith(PROTECTED_PREFIXES):
        return True
    if os.path.basename(lowered) in PROTECTED_NAMES:
        return True
    return lowered.endswith(PROTECTED_EXTENSIONS)


class Updater:
    def __init__(self):
        self.addon = xbmcaddon.Addon(ADDON_ID)
        self.dialog = xbmcgui.Dialog()
        self.home = kodi_path('special://home')
        self.data = kodi_path('special://profile/addon_data/{}/'.format(ADDON_ID))
        self.downloads = os.path.join(self.data, 'downloads')
        self.backups = os.path.join(self.data, 'backups')
        self.state_file = os.path.join(self.data, 'installed.json')
        self.activation_file = os.path.join(self.data, 'pending-activation.json')
        self.activation_error_file = os.path.join(
            self.data, 'activation-error.json')
        self.install_lock = os.path.join(self.data, 'installing.lock')
        for directory in (self.data, self.downloads, self.backups):
            os.makedirs(directory, exist_ok=True)

    def cleanup_update_storage(self):
        if os.path.exists(self.install_lock):
            log('Skipping updater storage cleanup while an installation is active.')
            return 0
        released = 0
        for directory in (self.downloads, self.backups):
            if not os.path.isdir(directory):
                continue
            for name in os.listdir(directory):
                target = os.path.join(directory, name)
                try:
                    if os.path.isfile(target) or os.path.islink(target):
                        released += os.path.getsize(target)
                        os.remove(target)
                    elif os.path.isdir(target):
                        for root, _dirs, files in os.walk(target):
                            for filename in files:
                                try:
                                    released += os.path.getsize(
                                        os.path.join(root, filename))
                                except OSError:
                                    pass
                        shutil.rmtree(target)
                except OSError as exc:
                    log('Unable to remove updater storage {}: {}'.format(
                        target, exc), xbmc.LOGWARNING)
        return released

    @property
    def manifest_url(self):
        return self.addon.getSettingString('manifest_url').strip()

    def installed_state(self):
        try:
            with open(self.state_file, 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            if isinstance(state, dict):
                return state
        except (OSError, ValueError):
            pass
        return {'version': DEFAULT_VERSION, 'name': BUILD_NAME}

    def write_state(self, version, manifest=None):
        state = {
            'name': BUILD_NAME,
            'version': version,
            'installed_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'channel': (manifest or {}).get('channel', 'development'),
        }
        temporary = self.state_file + '.tmp'
        with open(temporary, 'w', encoding='utf-8') as handle:
            json.dump(state, handle, indent=2, sort_keys=True)
        os.replace(temporary, self.state_file)

    def request_activation(self, version):
        with open(self.activation_file + '.tmp', 'w', encoding='utf-8') as handle:
            json.dump({'version': version, 'skin_attempts': 0}, handle)
        os.replace(self.activation_file + '.tmp', self.activation_file)

    def activation_state(self):
        try:
            with open(self.activation_file, 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            return state if isinstance(state, dict) else {}
        except (OSError, ValueError):
            return {}

    def write_activation_error(self, message, details=None):
        report = {
            'time': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'message': message,
            'details': details or {},
        }
        try:
            with open(self.activation_error_file + '.tmp', 'w',
                      encoding='utf-8') as handle:
                json.dump(report, handle, indent=2, sort_keys=True)
            os.replace(
                self.activation_error_file + '.tmp', self.activation_error_file)
        except OSError as exc:
            log('Unable to save activation error: {}'.format(exc), xbmc.LOGERROR)

    @staticmethod
    def json_rpc(method, params=None):
        request = {
            'jsonrpc': '2.0',
            'id': 1,
            'method': method,
        }
        if params is not None:
            request['params'] = params
        try:
            response = xbmc.executeJSONRPC(json.dumps(request))
            return json.loads(response)
        except (TypeError, ValueError) as exc:
            return {'error': {'message': 'Invalid JSON-RPC response: {}'.format(exc)}}

    def active_skin(self):
        response = self.json_rpc(
            'Settings.GetSettingValue', {'setting': 'lookandfeel.skin'})
        return response.get('result', {}).get('value', ''), response

    @staticmethod
    def accept_skin_confirmation(monitor):
        """Accept Kodi's timed skin-change confirmation before it rolls back."""
        confirmation_seen = False
        for _attempt in range(40):
            if monitor.abortRequested():
                return False
            if xbmc.getCondVisibility('Window.IsActive(yesnodialog)'):
                confirmation_seen = True
                log('Accepting Kodi skin-change confirmation.')
                xbmc.executebuiltin('SendClick(11)')
                break
            xbmc.sleep(100)
        if confirmation_seen:
            for _attempt in range(40):
                if monitor.abortRequested():
                    return False
                if not xbmc.getCondVisibility('Window.IsActive(yesnodialog)'):
                    return True
                xbmc.sleep(100)
            return False
        # Some Kodi platforms apply this setting without showing a dialog.
        return True

    def activate_build(self):
        if not os.path.exists(self.activation_file):
            return False
        enabled_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 'enabled_addons.json')
        try:
            with open(enabled_path, 'r', encoding='utf-8') as handle:
                addon_ids = json.load(handle)
        except (OSError, ValueError) as exc:
            log('Unable to read enabled add-on list: {}'.format(exc), xbmc.LOGERROR)
            return False

        monitor = xbmc.Monitor()
        progress = xbmcgui.DialogProgress()
        progress.create(
            'Kodi Simkl Build Setup',
            'Preparing add-ons and Arctic Horizon 2. Please wait…')
        last_error = {}
        try:
            ordered_ids = list(dict.fromkeys(SKIN_DEPENDENCIES + tuple(addon_ids)))
            for attempt in range(1, 7):
                progress.update(
                    5 + ((attempt - 1) * 8),
                    'Refreshing Kodi add-ons (attempt {}/6)…'.format(attempt))
                xbmc.executebuiltin('UpdateLocalAddons')
                wait_seconds = 12 if attempt == 1 else 4
                for remaining in range(wait_seconds, 0, -1):
                    if monitor.waitForAbort(1):
                        return False
                    progress.update(
                        8 + ((attempt - 1) * 8),
                        'Waiting for Kodi add-ons… {} seconds'.format(remaining))

                failed = {}
                total = max(1, len(ordered_ids))
                for index, addon_id in enumerate(ordered_ids, 1):
                    progress.update(
                        20 + int((index / total) * 50),
                        'Enabling required add-ons…\n{}'.format(addon_id))
                    response = self.json_rpc('Addons.SetAddonEnabled', {
                        'addonid': addon_id,
                        'enabled': True,
                    })
                    if 'error' in response:
                        failed[addon_id] = response['error']

                required_failed = [addon_id for addon_id in REQUIRED_ACTIVATION
                                   if addon_id in failed]
                dependency_failed = [addon_id for addon_id in SKIN_DEPENDENCIES
                                     if addon_id in failed]
                if required_failed or dependency_failed:
                    last_error = {
                        addon_id: failed[addon_id]
                        for addon_id in dict.fromkeys(
                            required_failed + dependency_failed)
                    }
                    log('Activation attempt {} dependency errors: {}'.format(
                        attempt, last_error), xbmc.LOGWARNING)
                    continue

                progress.update(78, 'Required add-ons are ready.\nApplying skin…')
                active_skin, verify_response = self.active_skin()
                if active_skin != 'skin.arctic.horizon.2':
                    activation = self.activation_state()
                    skin_attempts = int(activation.get('skin_attempts', 0) or 0)
                    if skin_attempts >= 1:
                        last_error = {
                            'skin': 'Kodi stopped during the previous skin switch',
                            'active_skin': active_skin,
                        }
                        break
                    activation['skin_attempts'] = skin_attempts + 1
                    with open(self.activation_file + '.tmp', 'w',
                              encoding='utf-8') as handle:
                        json.dump(activation, handle)
                    os.replace(
                        self.activation_file + '.tmp', self.activation_file)
                    progress.update(92, 'Loading Arctic Horizon 2…')
                    # The progress dialog belongs to the old skin and must be
                    # closed before Kodi creates its skin confirmation dialog.
                    progress.close()
                    skin_response = self.json_rpc('Settings.SetSettingValue', {
                        'setting': 'lookandfeel.skin',
                        'value': 'skin.arctic.horizon.2',
                    })
                    if 'error' in skin_response:
                        last_error = {'skin_response': skin_response}
                        break
                    if not self.accept_skin_confirmation(monitor):
                        last_error = {
                            'skin_confirmation': 'Kodi did not accept or close the confirmation dialog'
                        }
                        break
                    if monitor.waitForAbort(3):
                        return False
                else:
                    progress.update(92, 'Finishing Arctic Horizon 2…')
                    progress.close()
                    xbmc.executebuiltin('ReloadSkin')
                    if monitor.waitForAbort(3):
                        return False
                active_skin, verify_response = self.active_skin()
                if active_skin == 'skin.arctic.horizon.2':
                    if os.path.isfile(self.activation_file):
                        os.remove(self.activation_file)
                    if os.path.isfile(self.activation_error_file):
                        os.remove(self.activation_error_file)
                    log('Activation verified; active skin is {}.'.format(active_skin))
                    self.dialog.notification(
                        'Kodi Simkl Build Setup', 'Build setup complete.',
                        xbmcgui.NOTIFICATION_INFO, 4000)
                    return True
                last_error = {
                    'active_skin': active_skin,
                    'verify_response': verify_response,
                }
                break
        except Exception as exc:
            last_error = {'exception': repr(exc)}
            log('Activation exception: {}'.format(exc), xbmc.LOGERROR)
        finally:
            progress.close()

        message = (
            'Build setup could not finish. Kodi kept the safe default skin. '
            'Open Build Setup > Show recent Kodi errors for details.')
        self.write_activation_error(message, last_error)
        log('{} Details: {}'.format(message, last_error), xbmc.LOGERROR)
        self.dialog.ok('Kodi Simkl Build Setup', message)
        return False

    def remove_retired_addons(self):
        for addon_id in RETIRED_ADDONS:
            for root in ('addons', 'userdata/addon_data'):
                target = os.path.join(self.home, *root.split('/'), addon_id)
                if os.path.isdir(target):
                    shutil.rmtree(target, ignore_errors=True)

    def read_source(self, source):
        if not source:
            raise UpdateError('No manifest URL is configured.')
        if source.startswith('special://'):
            source = kodi_path(source)
        parsed = urllib.parse.urlparse(source)
        if parsed.scheme in ('http', 'https'):
            request = urllib.request.Request(
                source, headers={'User-Agent': 'Mokhan-Kodi-Updater/0.1'})
            with urllib.request.urlopen(request, timeout=30) as response:
                return response.read()
        if parsed.scheme == 'file':
            source = urllib.request.url2pathname(parsed.path)
        with open(source, 'rb') as handle:
            return handle.read()

    def get_manifest(self):
        try:
            manifest = json.loads(self.read_source(self.manifest_url).decode('utf-8'))
        except (ValueError, UnicodeError, OSError) as exc:
            raise UpdateError('Unable to read update manifest: {}'.format(exc))
        if not isinstance(manifest, dict) or not manifest.get('version'):
            raise UpdateError('The update manifest is invalid.')
        minimum_kodi = int(manifest.get('minimum_kodi', 21))
        kodi_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        if kodi_major < minimum_kodi:
            raise UpdateError('This update requires Kodi {} or newer.'.format(minimum_kodi))
        return manifest

    def package_url(self, manifest):
        package = manifest.get('package_url') or ''
        if not package:
            raise UpdateError('This manifest does not have a downloadable package yet.')
        if self.manifest_url.startswith(('http://', 'https://')):
            return urllib.parse.urljoin(self.manifest_url, package)
        if package.startswith(('http://', 'https://', 'special://', 'file:')):
            return package
        return os.path.join(os.path.dirname(self.manifest_url), package)

    def download_package(self, manifest, progress=None):
        destination = os.path.join(self.downloads, 'update-{}.zip'.format(manifest['version']))
        source = self.package_url(manifest)
        digest = hashlib.sha256()
        if source.startswith('special://'):
            source = kodi_path(source)
        parsed = urllib.parse.urlparse(source)
        try:
            if parsed.scheme in ('http', 'https'):
                request = urllib.request.Request(
                    source, headers={'User-Agent': 'Mokhan-Kodi-Updater/0.1'})
                input_handle = urllib.request.urlopen(request, timeout=60)
            else:
                if parsed.scheme == 'file':
                    source = urllib.request.url2pathname(parsed.path)
                input_handle = open(source, 'rb')
            total = 0
            try:
                total = int(input_handle.headers.get('Content-Length') or 0)
            except (AttributeError, TypeError, ValueError):
                try:
                    total = os.path.getsize(source)
                except OSError:
                    total = 0
            downloaded = 0
            with input_handle, open(destination + '.tmp', 'wb') as output:
                while True:
                    if progress:
                        progress.check_cancelled()
                    chunk = input_handle.read(1024 * 1024)
                    if not chunk:
                        break
                    digest.update(chunk)
                    output.write(chunk)
                    downloaded += len(chunk)
                    if progress:
                        ratio = (downloaded / total) if total else 0
                        detail = '{} downloaded'.format(format_bytes(downloaded))
                        if total:
                            detail = '{} of {}'.format(
                                format_bytes(downloaded), format_bytes(total))
                        progress.update(
                            5 + int(ratio * 35), 'Downloading build', detail,
                            manifest.get('version'))
            if progress:
                progress.set_cancellable(False)
                progress.update(42, 'Verifying download', 'Checking SHA-256 signature…',
                                manifest.get('version'))
            expected = (manifest.get('sha256') or '').lower()
            if not expected or digest.hexdigest().lower() != expected:
                raise UpdateError('Package checksum verification failed.')
            os.replace(destination + '.tmp', destination)
            return destination
        except OSError as exc:
            raise UpdateError('Unable to download update package: {}'.format(exc))
        finally:
            if os.path.exists(destination + '.tmp'):
                os.remove(destination + '.tmp')

    def validate_archive(self, archive_path, progress=None, version=''):
        installable = []
        try:
            with zipfile.ZipFile(archive_path, 'r') as archive:
                for info in archive.infolist():
                    if info.is_dir():
                        continue
                    name = normalize_relative(info.filename)
                    if not name.startswith('payload/'):
                        raise UpdateError('Every package file must be inside payload/.')
                    relative_path = normalize_relative(name[len('payload/'):])
                    if relative_path.split('/')[0].lower() not in ALLOWED_ROOTS:
                        raise UpdateError('Package contains a disallowed root: {}'.format(relative_path))
                    if is_protected(relative_path):
                        log('Protected file skipped: {}'.format(relative_path))
                        continue
                    installable.append((info, relative_path))
                    if progress and len(installable) % 250 == 0:
                        progress.update(46, 'Inspecting package',
                                        '{} files verified'.format(len(installable)), version)
        except (OSError, zipfile.BadZipFile) as exc:
            raise UpdateError('The update package is not a valid ZIP: {}'.format(exc))
        if not installable:
            raise UpdateError('The update package has no installable files.')
        return installable

    def apply_archive(self, archive_path, installable, progress=None, version=''):
        staging = tempfile.mkdtemp(prefix='mokhan-update-', dir=self.data)
        try:
            total = max(1, len(installable))
            with zipfile.ZipFile(archive_path, 'r') as archive:
                for index, (info, relative_path) in enumerate(installable, 1):
                    staged = os.path.join(staging, *relative_path.split('/'))
                    os.makedirs(os.path.dirname(staged), exist_ok=True)
                    with archive.open(info, 'r') as source, open(staged, 'wb') as target:
                        shutil.copyfileobj(source, target)
                    if progress and index % 100 == 0:
                        progress.update(
                            58 + int((index / total) * 14), 'Extracting update',
                            '{} of {} files'.format(index, total), version)
            for index, (_info, relative_path) in enumerate(installable, 1):
                source = os.path.join(staging, *relative_path.split('/'))
                target = os.path.join(self.home, *relative_path.split('/'))
                os.makedirs(os.path.dirname(target), exist_ok=True)
                temporary_target = target + '.mokhan-new'
                try:
                    if os.path.exists(temporary_target):
                        os.remove(temporary_target)
                    shutil.copyfile(source, temporary_target)
                    try:
                        os.chmod(temporary_target, 0o644)
                    except OSError:
                        pass
                    if os.path.exists(target):
                        try:
                            os.chmod(target, 0o600)
                        except OSError:
                            pass
                    os.replace(temporary_target, target)
                finally:
                    if os.path.exists(temporary_target):
                        os.remove(temporary_target)
                if progress and index % 100 == 0:
                    progress.update(
                        72 + int((index / total) * 20), 'Installing build',
                        '{} of {} files'.format(index, total), version)
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def clear_portable_widget_caches(self):
        """Discard device-specific widget output after installing new definitions."""
        widget_cache = os.path.join(
            self.home, 'userdata', 'addon_data',
            'plugin.video.themoviedb.helper', 'widget_cache')
        if os.path.isdir(widget_cache):
            shutil.rmtree(widget_cache, ignore_errors=True)

        shortcuts_data = os.path.join(
            self.home, 'userdata', 'addon_data', 'script.skinshortcuts')
        if os.path.isdir(shortcuts_data):
            for name in os.listdir(shortcuts_data):
                if name.lower().endswith('.hash'):
                    try:
                        os.remove(os.path.join(shortcuts_data, name))
                    except OSError as exc:
                        log('Unable to remove stale skin shortcut hash {}: {}'.format(name, exc), xbmc.LOGWARNING)

    def install(self, manifest, progress=None):
        version = manifest.get('version', '')
        archive_path = ''
        with open(self.install_lock, 'w', encoding='utf-8') as handle:
            handle.write(version or 'installing')
        try:
            archive_path = self.download_package(manifest, progress=progress)
            if progress:
                progress.update(
                    45, 'Inspecting package',
                    'Validating archive contents…', version)
            installable = self.validate_archive(
                archive_path, progress=progress, version=version)
            self.apply_archive(
                archive_path, installable, progress=progress, version=version)
            if progress:
                progress.update(94, 'Refreshing Kodi',
                                'Clearing stale widget mappings…', version)
            self.clear_portable_widget_caches()
            self.remove_retired_addons()
            self.write_state(manifest['version'], manifest)
            self.request_activation(manifest['version'])
            if progress:
                progress.update(100, 'Update installed',
                                'Restart Kodi to activate the build.', version)
            return len(installable)
        finally:
            try:
                if archive_path and os.path.isfile(archive_path):
                    os.remove(archive_path)
            except OSError as exc:
                log('Unable to remove downloaded update: {}'.format(exc),
                    xbmc.LOGWARNING)
            try:
                if os.path.isfile(self.install_lock):
                    os.remove(self.install_lock)
            except OSError as exc:
                log('Unable to remove installation lock: {}'.format(exc),
                    xbmc.LOGWARNING)

    def check(self, interactive=True):
        manifest = self.get_manifest()
        installed = self.installed_state().get('version', DEFAULT_VERSION)
        available = manifest['version']
        if version_key(available) <= version_key(installed):
            if interactive:
                self.dialog.ok(BUILD_NAME, 'Your build is up to date.\nInstalled: {}'.format(installed))
            return False
        if not interactive:
            xbmcgui.Dialog().notification(
                BUILD_NAME, 'Build update {} is available'.format(available),
                xbmcgui.NOTIFICATION_INFO, 6000)
            return True
        notes = manifest.get('release_notes') or 'A new build update is available.'
        if not self.dialog.yesno(
                BUILD_NAME,
                'Installed: {}\nAvailable: {}\n\n{}\n\nInstall now?'.format(
                    installed, available, notes)):
            return True
        progress = create_progress(self.addon.getAddonInfo('path'))
        progress.update(2, 'Preparing update', 'Connecting to the release channel…', available)
        try:
            count = self.install(manifest, progress=progress)
            xbmc.sleep(400)
        except InstallCancelled as exc:
            progress.close()
            self.dialog.ok(BUILD_NAME, str(exc))
            return True
        except Exception:
            progress.close()
            raise
        progress.close()
        restart = self.dialog.yesno(
            BUILD_NAME,
            'Update {} installed ({} files).\nDownloaded package removed.\n\nRestart Kodi now?'.format(
                available, count))
        if restart:
            xbmc.executebuiltin('RestartApp')
        return True

    def check_background(self):
        try:
            self.check(interactive=False)
        except UpdateError as exc:
            log(str(exc), xbmc.LOGWARNING)

    def show_status(self):
        if not os.path.isfile(self.state_file):
            self.dialog.ok(BUILD_NAME, 'The managed build has not been installed yet.')
            return
        state = self.installed_state()
        self.dialog.ok(
            BUILD_NAME,
            'Installed version: {}\nChannel: {}\nManifest: {}'.format(
                state.get('version', DEFAULT_VERSION),
                state.get('channel', 'development'),
                self.manifest_url))

    def build_install_label(self):
        if not os.path.isfile(self.state_file):
            return 'Install Build  [COLOR yellow]Not installed[/COLOR]'
        version = self.installed_state().get('version', 'Unknown')
        return 'Build Installed  [COLOR limegreen]✓ Version {}[/COLOR]'.format(version)

    def install_or_status(self):
        if os.path.isfile(self.state_file):
            self.show_status()
        else:
            self.check(interactive=True)

    def addon_installed(self, addon_id):
        response = self.json_rpc('Addons.GetAddons', {
            'properties': ['version'],
        })
        for addon in response.get('result', {}).get('addons', []):
            if addon.get('addonid') == addon_id:
                return True, addon.get('version', '')
        return False, ''

    def otaku_install_label(self):
        installed, version = self.addon_installed('plugin.video.otaku.testing')
        if installed:
            return 'Otaku Testing  [COLOR limegreen]✓ Installed v{}[/COLOR]'.format(
                version or 'Unknown')
        return 'Install Otaku Testing  [COLOR yellow]Optional — Not installed[/COLOR]'

    def install_otaku_components(self):
        if not self.enable_addon('repository.otaku.testing', 'Otaku repository'):
            return False
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.sleep(1500)
        for addon_id in OTAKU_INSTALL_ORDER:
            xbmc.executebuiltin('InstallAddon({})'.format(addon_id))
        monitor = xbmc.Monitor()
        for _attempt in range(12):
            if monitor.waitForAbort(2):
                return False
            xbmc.executebuiltin('UpdateLocalAddons')
            installed, _version = self.addon_installed(
                'plugin.video.otaku.testing')
            if not installed:
                continue
            for addon_id in OTAKU_INSTALL_ORDER:
                self.json_rpc('Addons.SetAddonEnabled', {
                    'addonid': addon_id,
                    'enabled': True,
                })
            return True
        return False

    def manage_otaku(self):
        installed, version = self.addon_installed('plugin.video.otaku.testing')
        if not installed:
            if not self.dialog.yesno(
                    SETUP_NAME,
                    'Otaku Testing is optional. Install it now?'):
                return
            if self.install_otaku_components():
                self.dialog.ok(
                    SETUP_NAME,
                    'Otaku Testing was installed successfully.')
            else:
                self.dialog.ok(
                    SETUP_NAME,
                    'Otaku installation did not finish. Check the Kodi log and try again.')
            return
        choice = self.dialog.select(
            'Otaku Testing v{}'.format(version or 'Unknown'), [
                'Open Otaku Testing',
                'Open Otaku settings',
                'Check for updates / repair installation',
            ])
        if choice == 0:
            xbmc.executebuiltin(
                'ActivateWindow(Videos,plugin://plugin.video.otaku.testing/,return)')
        elif choice == 1:
            try:
                xbmcaddon.Addon('plugin.video.otaku.testing').openSettings()
            except (RuntimeError, AttributeError):
                self.dialog.ok(SETUP_NAME, 'Otaku Testing is not available.')
        elif choice == 2:
            if self.install_otaku_components():
                self.dialog.ok(SETUP_NAME, 'Otaku Testing is installed and enabled.')
            else:
                self.dialog.ok(SETUP_NAME, 'Unable to repair the Otaku installation.')

    def show_recent_errors(self):
        log_path = kodi_path('special://logpath/kodi.log')
        activation_report = ''
        try:
            with open(self.activation_error_file, 'r', encoding='utf-8') as handle:
                activation_report = json.dumps(
                    json.load(handle), indent=2, sort_keys=True)
        except (OSError, ValueError):
            pass
        try:
            with open(log_path, 'r', encoding='utf-8', errors='replace') as handle:
                lines = handle.readlines()[-3000:]
        except OSError as exc:
            self.dialog.ok(BUILD_NAME, 'Unable to read kodi.log: {}'.format(exc))
            return
        markers = (
            ' error ', 'exception', 'traceback', 'plugin.video.seren',
            'otaku testing', '[mokhan build updater]', 'activation attempt',
        )
        matches = [index for index, line in enumerate(lines)
                   if any(marker in line.lower() for marker in markers)]
        included = set()
        for index in matches:
            included.update(range(max(0, index - 2), min(len(lines), index + 16)))
        relevant = [lines[index].rstrip() for index in sorted(included)]
        message = '\n'.join(relevant[-180:]) or 'No recent Kodi or add-on errors were found.'
        if activation_report:
            message = 'LAST BUILD ACTIVATION REPORT\n{}\n\n{}'.format(
                activation_report, message)
        self.dialog.textviewer('Recent Kodi / add-on errors', message)

    @staticmethod
    def account_label(name, connected, enabled=True):
        if connected and enabled:
            return '{}  [COLOR limegreen]✓ Connected[/COLOR]'.format(name)
        if connected:
            return '{}  [COLOR yellow]● Connected — Disabled[/COLOR]'.format(name)
        return '{}  [COLOR grey]Not connected[/COLOR]'.format(name)

    def addon_setting(self, addon_id, setting_id):
        installed, _version = self.addon_installed(addon_id)
        if not installed:
            return ''
        try:
            return xbmcaddon.Addon(addon_id).getSetting(setting_id).strip()
        except (RuntimeError, AttributeError):
            return ''

    @staticmethod
    def open_build_setup():
        xbmc.executebuiltin(
            'ActivateWindow(Programs,plugin://plugin.program.mokhan.updater/,return)')

    def enable_addon(self, addon_id, name):
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(500)
        response = self.json_rpc('Addons.SetAddonEnabled', {
            'addonid': addon_id,
            'enabled': True,
        })
        if 'error' in response:
            self.dialog.ok(
                SETUP_NAME,
                'Unable to enable the required {} dependency.'.format(name))
            log('Unable to enable {}: {}'.format(addon_id, response['error']),
                xbmc.LOGERROR)
            return False
        return True

    def simkl_accounts(self):
        tmdb_connected = bool(self.addon_setting(
            'plugin.video.themoviedb.helper', 'simkl_token'))
        otaku_connected = bool(self.addon_setting(
            'plugin.video.otaku.testing', 'simkl.token'))
        otaku_enabled = self.addon_setting(
            'plugin.video.otaku.testing', 'simkl.enabled').lower() == 'true'
        return (
            ('TMDb Helper', tmdb_connected, True),
            ('Otaku Testing', otaku_connected, otaku_enabled),
        )

    def simkl_label(self):
        accounts = self.simkl_accounts()
        connected = sum(1 for item in accounts if item[1] and item[2])
        if connected:
            return 'Connect Simkl  [COLOR limegreen]✓ {}/2 connected[/COLOR]'.format(
                connected)
        return 'Connect Simkl  [COLOR grey]None connected[/COLOR]'

    def connect_simkl(self):
        accounts = self.simkl_accounts()
        labels = [self.account_label(*item) for item in accounts]
        choice = self.dialog.select('Connect Simkl', labels)
        if choice == 0:
            xbmc.executebuiltin(
                'RunScript(plugin.video.themoviedb.helper,authenticate_simkl)')
            return True
        elif choice == 1:
            installed, _version = self.addon_installed(
                'plugin.video.otaku.testing')
            if not installed:
                self.manage_otaku()
                return False
            if not self.enable_addon('script.module.pyqrcode', 'pyQRcode'):
                return False
            try:
                xbmcaddon.Addon('plugin.video.otaku.testing').setSetting(
                    'simkl.enabled', 'true')
            except (RuntimeError, AttributeError):
                self.dialog.ok(SETUP_NAME, 'Otaku Testing is not available.')
                return False
            xbmc.executebuiltin(
                'RunPlugin(plugin://plugin.video.otaku.testing/watchlist_login/simkl)')
            return True
        return False

    def seren_debrid_services(self):
        seren_id = 'plugin.video.seren'
        definitions = (
            ('Real-Debrid', 'authRealDebrid', 'rd.auth', 'realdebrid.enabled'),
            ('Premiumize', 'smartAuthPremiumize', 'premiumize.token', 'premiumize.enabled'),
            ('AllDebrid', 'authAllDebrid', 'alldebrid.apikey', 'alldebrid.enabled'),
            ('TorBox', 'authTorBox', 'torbox.token', 'torbox.enabled'),
            ('Debrid-Link', 'authDebridLink', 'debridlink.token', 'debridlink.enabled'),
            ('Offcloud', 'authOffcloud', 'offcloud.apikey', 'offcloud.enabled'),
        )
        services = []
        for name, action, token_id, enabled_id in definitions:
            connected = bool(self.addon_setting(seren_id, token_id))
            enabled = self.addon_setting(seren_id, enabled_id).lower() == 'true'
            services.append((name, action, connected, enabled))
        return services

    def otaku_debrid_services(self):
        otaku_id = 'plugin.video.otaku.testing'
        definitions = (
            ('Real-Debrid', 'realdebrid', 'realdebrid.token', 'realdebrid.enabled'),
            ('Premiumize', 'premiumize', 'premiumize.token', 'premiumize.enabled'),
            ('AllDebrid', 'alldebrid', 'alldebrid.token', 'alldebrid.enabled'),
            ('TorBox', 'torbox', 'torbox.token', 'torbox.enabled'),
            ('Debrid-Link', 'debridlink', 'debridlink.token', 'debridlink.enabled'),
            ('EasyDebrid', 'easydebrid', 'easydebrid.token', 'easydebrid.enabled'),
        )
        services = []
        for name, action, token_id, enabled_id in definitions:
            connected = bool(self.addon_setting(otaku_id, token_id))
            enabled = self.addon_setting(otaku_id, enabled_id).lower() == 'true'
            services.append((name, action, connected, enabled, enabled_id))
        return services

    @staticmethod
    def service_group_label(name, services):
        active = sum(1 for item in services if item[2] and item[3])
        if active:
            return '{}  [COLOR limegreen]✓ {} active[/COLOR]'.format(name, active)
        return '{}  [COLOR grey]None connected[/COLOR]'.format(name)

    def debrid_menu_label(self):
        services = self.seren_debrid_services() + self.otaku_debrid_services()
        active = sum(1 for item in services if item[2] and item[3])
        if active:
            return 'Connect Debrid Account  [COLOR limegreen]✓ {} active[/COLOR]'.format(active)
        return 'Connect Debrid Account  [COLOR grey]None connected[/COLOR]'

    def connect_debrid(self):
        seren = self.seren_debrid_services()
        otaku = self.otaku_debrid_services()
        choice = self.dialog.select('Connect Debrid Account', [
            self.service_group_label('Seren', seren),
            self.service_group_label('Otaku Testing', otaku),
        ])
        if choice == 0:
            return self.connect_seren_debrid(seren)
        elif choice == 1:
            installed, _version = self.addon_installed(
                'plugin.video.otaku.testing')
            if not installed:
                self.manage_otaku()
                return False
            return self.connect_otaku_debrid(otaku)
        return False

    def connect_seren_debrid(self, services=None):
        services = services or self.seren_debrid_services()
        labels = [self.account_label(item[0], item[2], item[3]) for item in services]
        choice = self.dialog.select('Seren — Debrid Account', labels)
        if choice < 0:
            return False
        xbmc.executebuiltin(
            'RunPlugin(plugin://plugin.video.seren/?action={})'.format(services[choice][1]))
        return True

    def connect_otaku_debrid(self, services=None):
        services = services or self.otaku_debrid_services()
        labels = [self.account_label(item[0], item[2], item[3]) for item in services]
        choice = self.dialog.select('Otaku Testing — Debrid Account', labels)
        if choice < 0:
            return False
        service = services[choice]
        try:
            xbmcaddon.Addon('plugin.video.otaku.testing').setSetting(
                service[4], 'true')
        except (RuntimeError, AttributeError):
            self.dialog.ok(SETUP_NAME, 'Otaku Testing is not available.')
            return False
        xbmc.executebuiltin(
            'RunPlugin(plugin://plugin.video.otaku.testing/auth/{})'.format(service[1]))
        return True

    def run_interactive(self):
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            choice = self.dialog.select(SETUP_NAME, [
                self.build_install_label(),
                self.otaku_install_label(),
                'Check for updates',
                'Activate build add-ons and skin',
                'Show recent Kodi errors',
                self.simkl_label(),
                self.debrid_menu_label(),
                'Settings',
            ])
            if choice < 0:
                # Let Kodi's window history handle Back from the main menu.
                return
            try:
                if choice == 0:
                    self.install_or_status()
                elif choice == 1:
                    self.manage_otaku()
                elif choice == 2:
                    self.check(interactive=True)
                elif choice == 3:
                    self.request_activation(
                        self.installed_state().get('version', DEFAULT_VERSION))
                    restart = self.dialog.yesno(
                        BUILD_NAME,
                        'Kodi must restart to safely enable the build add-ons '
                        'and apply Arctic Horizon 2.\n\nRestart Kodi now?')
                    if restart:
                        xbmc.executebuiltin('RestartApp')
                    return
                elif choice == 4:
                    self.show_recent_errors()
                elif choice == 5:
                    if self.connect_simkl():
                        return
                elif choice == 6:
                    if self.connect_debrid():
                        return
                elif choice == 7:
                    self.addon.openSettings()
            except UpdateError as exc:
                log(str(exc), xbmc.LOGERROR)
                self.dialog.ok(BUILD_NAME, str(exc))
            except Exception as exc:
                log('Unexpected error: {}'.format(exc), xbmc.LOGERROR)
                self.dialog.ok(BUILD_NAME, 'Update failed: {}'.format(exc))
