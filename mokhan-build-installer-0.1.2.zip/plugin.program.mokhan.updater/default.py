from resources.lib.updater import Updater


if __name__ == '__main__':
    Updater().run_interactive()
