from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON_ID = 'plugin.program.mokhan.updater'
BUILD_NAME = 'Kodi Simkl Build'
DEFAULT_VERSION = '0.1.0'
ALLOWED_ROOTS = ('addons', 'userdata', 'media', 'system')
PROTECTED_SETTINGS = (
    'userdata/addon_data/plugin.video.seren/settings.xml',
    'userdata/addon_data/plugin.video.themoviedb.helper/settings.xml',
    'userdata/addon_data/script.trakt/settings.xml',
)
PROTECTED_PREFIXES = (
    'userdata/addon_data/plugin.program.mokhan.updater/',
    'userdata/addon_data/plugin.video.themoviedb.helper/database_',
)
PROTECTED_NAMES = ('passwords.xml', 'sources.xml', 'profiles.xml')
PROTECTED_EXTENSIONS = ('.db', '.sqlite', '.sqlite3', '.log', '.dmp')


class UpdateError(Exception):
    pass


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[Mokhan Build Updater] {}'.format(message), level)


def kodi_path(path):
    return xbmcvfs.translatePath(path)


def version_key(value):
    return tuple(int(part) for part in re.findall(r'\d+', value or '0'))


def normalize_relative(path):
    path = path.replace('\\', '/').lstrip('/')
    normalized = os.path.normpath(path).replace('\\', '/')
    if normalized in ('', '.') or normalized == '..' or normalized.startswith('../'):
        raise UpdateError('Unsafe archive path: {}'.format(path))
    if ':' in normalized.split('/')[0]:
        raise UpdateError('Unsafe archive path: {}'.format(path))
    return normalized


def is_protected(relative_path):
    lowered = relative_path.lower()
    if lowered in PROTECTED_SETTINGS:
        return True
    if lowered.startswith(PROTECTED_PREFIXES):
        return True
    if os.path.basename(lowered) in PROTECTED_NAMES:
        return True
    return lowered.endswith(PROTECTED_EXTENSIONS)


class Updater:
    def __init__(self):
        self.addon = xbmcaddon.Addon(ADDON_ID)
        self.dialog = xbmcgui.Dialog()
        self.home = kodi_path('special://home')
        self.data = kodi_path('special://profile/addon_data/{}/'.format(ADDON_ID))
        self.downloads = os.path.join(self.data, 'downloads')
        self.backups = os.path.join(self.data, 'backups')
        self.state_file = os.path.join(self.data, 'installed.json')
        for directory in (self.data, self.downloads, self.backups):
            os.makedirs(directory, exist_ok=True)

    @property
    def manifest_url(self):
        return self.addon.getSettingString('manifest_url').strip()

    def installed_state(self):
        try:
            with open(self.state_file, 'r', encoding='utf-8') as handle:
                state = json.load(handle)
            if isinstance(state, dict):
                return state
        except (OSError, ValueError):
            pass
        return {'version': DEFAULT_VERSION, 'name': BUILD_NAME}

    def write_state(self, version, manifest=None):
        state = {
            'name': BUILD_NAME,
            'version': version,
            'installed_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'channel': (manifest or {}).get('channel', 'development'),
        }
        temporary = self.state_file + '.tmp'
        with open(temporary, 'w', encoding='utf-8') as handle:
            json.dump(state, handle, indent=2, sort_keys=True)
        os.replace(temporary, self.state_file)

    def read_source(self, source):
        if not source:
            raise UpdateError('No manifest URL is configured.')
        if source.startswith('special://'):
            source = kodi_path(source)
        parsed = urllib.parse.urlparse(source)
        if parsed.scheme in ('http', 'https'):
            request = urllib.request.Request(
                source, headers={'User-Agent': 'Mokhan-Kodi-Updater/0.1'})
            with urllib.request.urlopen(request, timeout=30) as response:
                return response.read()
        if parsed.scheme == 'file':
            source = urllib.request.url2pathname(parsed.path)
        with open(source, 'rb') as handle:
            return handle.read()

    def get_manifest(self):
        try:
            manifest = json.loads(self.read_source(self.manifest_url).decode('utf-8'))
        except (ValueError, UnicodeError, OSError) as exc:
            raise UpdateError('Unable to read update manifest: {}'.format(exc))
        if not isinstance(manifest, dict) or not manifest.get('version'):
            raise UpdateError('The update manifest is invalid.')
        minimum_kodi = int(manifest.get('minimum_kodi', 21))
        kodi_major = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        if kodi_major < minimum_kodi:
            raise UpdateError('This update requires Kodi {} or newer.'.format(minimum_kodi))
        return manifest

    def package_url(self, manifest):
        package = manifest.get('package_url') or ''
        if not package:
            raise UpdateError('This manifest does not have a downloadable package yet.')
        if self.manifest_url.startswith(('http://', 'https://')):
            return urllib.parse.urljoin(self.manifest_url, package)
        if package.startswith(('http://', 'https://', 'special://', 'file:')):
            return package
        return os.path.join(os.path.dirname(self.manifest_url), package)

    def download_package(self, manifest):
        destination = os.path.join(self.downloads, 'update-{}.zip'.format(manifest['version']))
        source = self.package_url(manifest)
        digest = hashlib.sha256()
        if source.startswith('special://'):
            source = kodi_path(source)
        parsed = urllib.parse.urlparse(source)
        try:
            if parsed.scheme in ('http', 'https'):
                request = urllib.request.Request(
                    source, headers={'User-Agent': 'Mokhan-Kodi-Updater/0.1'})
                input_handle = urllib.request.urlopen(request, timeout=60)
            else:
                if parsed.scheme == 'file':
                    source = urllib.request.url2pathname(parsed.path)
                input_handle = open(source, 'rb')
            with input_handle, open(destination + '.tmp', 'wb') as output:
                while True:
                    chunk = input_handle.read(1024 * 1024)
                    if not chunk:
                        break
                    digest.update(chunk)
                    output.write(chunk)
            expected = (manifest.get('sha256') or '').lower()
            if not expected or digest.hexdigest().lower() != expected:
                raise UpdateError('Package checksum verification failed.')
            os.replace(destination + '.tmp', destination)
            return destination
        except OSError as exc:
            raise UpdateError('Unable to download update package: {}'.format(exc))
        finally:
            if os.path.exists(destination + '.tmp'):
                os.remove(destination + '.tmp')

    def validate_archive(self, archive_path):
        installable = []
        try:
            with zipfile.ZipFile(archive_path, 'r') as archive:
                for info in archive.infolist():
                    if info.is_dir():
                        continue
                    name = normalize_relative(info.filename)
                    if not name.startswith('payload/'):
                        raise UpdateError('Every package file must be inside payload/.')
                    relative_path = normalize_relative(name[len('payload/'):])
                    if relative_path.split('/')[0].lower() not in ALLOWED_ROOTS:
                        raise UpdateError('Package contains a disallowed root: {}'.format(relative_path))
                    if is_protected(relative_path):
                        log('Protected file skipped: {}'.format(relative_path))
                        continue
                    installable.append((info, relative_path))
        except (OSError, zipfile.BadZipFile) as exc:
            raise UpdateError('The update package is not a valid ZIP: {}'.format(exc))
        if not installable:
            raise UpdateError('The update package has no installable files.')
        return installable

    def create_backup(self, installable):
        stamp = time.strftime('%Y%m%d-%H%M%S')
        backup_path = os.path.join(self.backups, 'backup-{}.zip'.format(stamp))
        backed_up = set()
        with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as archive:
            for _info, relative_path in installable:
                if relative_path in backed_up:
                    continue
                target = os.path.join(self.home, *relative_path.split('/'))
                if os.path.isfile(target):
                    archive.write(target, relative_path)
                    backed_up.add(relative_path)
            archive.writestr('_backup.json', json.dumps({
                'created_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
                'previous_version': self.installed_state().get('version', DEFAULT_VERSION),
            }, indent=2))
        return backup_path

    def apply_archive(self, archive_path, installable):
        staging = tempfile.mkdtemp(prefix='mokhan-update-', dir=self.data)
        try:
            with zipfile.ZipFile(archive_path, 'r') as archive:
                for info, relative_path in installable:
                    staged = os.path.join(staging, *relative_path.split('/'))
                    os.makedirs(os.path.dirname(staged), exist_ok=True)
                    with archive.open(info, 'r') as source, open(staged, 'wb') as target:
                        shutil.copyfileobj(source, target)
            for _info, relative_path in installable:
                source = os.path.join(staging, *relative_path.split('/'))
                target = os.path.join(self.home, *relative_path.split('/'))
                os.makedirs(os.path.dirname(target), exist_ok=True)
                temporary_target = target + '.mokhan-new'
                try:
                    if os.path.exists(temporary_target):
                        os.remove(temporary_target)
                    shutil.copyfile(source, temporary_target)
                    try:
                        os.chmod(temporary_target, 0o644)
                    except OSError:
                        pass
                    if os.path.exists(target):
                        try:
                            os.chmod(target, 0o600)
                        except OSError:
                            pass
                    os.replace(temporary_target, target)
                finally:
                    if os.path.exists(temporary_target):
                        os.remove(temporary_target)
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    def install(self, manifest):
        archive_path = self.download_package(manifest)
        installable = self.validate_archive(archive_path)
        backup_path = self.create_backup(installable)
        try:
            self.apply_archive(archive_path, installable)
            self.write_state(manifest['version'], manifest)
        except Exception:
            log('Installation failed; backup retained at {}'.format(backup_path), xbmc.LOGERROR)
            raise
        return backup_path, len(installable)

    def latest_backup(self):
        backups = sorted(
            (os.path.join(self.backups, name) for name in os.listdir(self.backups)
             if name.startswith('backup-') and name.endswith('.zip')),
            reverse=True)
        return backups[0] if backups else None

    def rollback(self):
        backup_path = self.latest_backup()
        if not backup_path:
            raise UpdateError('No updater backup is available.')
        with zipfile.ZipFile(backup_path, 'r') as archive:
            metadata = json.loads(archive.read('_backup.json').decode('utf-8'))
            for info in archive.infolist():
                if info.is_dir() or info.filename == '_backup.json':
                    continue
                relative_path = normalize_relative(info.filename)
                if is_protected(relative_path):
                    continue
                target = os.path.join(self.home, *relative_path.split('/'))
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with archive.open(info, 'r') as source, open(target, 'wb') as output:
                    shutil.copyfileobj(source, output)
        self.write_state(metadata.get('previous_version', DEFAULT_VERSION))
        return backup_path

    def check(self, interactive=True):
        manifest = self.get_manifest()
        installed = self.installed_state().get('version', DEFAULT_VERSION)
        available = manifest['version']
        if version_key(available) <= version_key(installed):
            if interactive:
                self.dialog.ok(BUILD_NAME, 'Your build is up to date.\nInstalled: {}'.format(installed))
            return False
        if not interactive:
            xbmcgui.Dialog().notification(
                BUILD_NAME, 'Build update {} is available'.format(available),
                xbmcgui.NOTIFICATION_INFO, 6000)
            return True
        notes = manifest.get('release_notes') or 'A new build update is available.'
        if not self.dialog.yesno(
                BUILD_NAME,
                'Installed: {}\nAvailable: {}\n\n{}\n\nInstall now?'.format(
                    installed, available, notes)):
            return True
        backup, count = self.install(manifest)
        restart = self.dialog.yesno(
            BUILD_NAME,
            'Update {} installed ({} files).\nBackup: {}\n\nRestart Kodi now?'.format(
                available, count, os.path.basename(backup)))
        if restart:
            xbmc.executebuiltin('RestartApp')
        return True

    def check_background(self):
        try:
            self.check(interactive=False)
        except UpdateError as exc:
            log(str(exc), xbmc.LOGWARNING)

    def show_status(self):
        state = self.installed_state()
        self.dialog.ok(
            BUILD_NAME,
            'Installed version: {}\nChannel: {}\nManifest: {}'.format(
                state.get('version', DEFAULT_VERSION),
                state.get('channel', 'development'),
                self.manifest_url))

    def run_interactive(self):
        choice = self.dialog.select(BUILD_NAME, [
            'Check for updates',
            'Show installed version',
            'Restore latest updater backup',
            'Settings',
        ])
        try:
            if choice == 0:
                self.check(interactive=True)
            elif choice == 1:
                self.show_status()
            elif choice == 2:
                if self.dialog.yesno(BUILD_NAME, 'Restore the latest updater backup?'):
                    backup = self.rollback()
                    if self.dialog.yesno(
                            BUILD_NAME,
                            'Restored {}. Restart Kodi now?'.format(os.path.basename(backup))):
                        xbmc.executebuiltin('RestartApp')
            elif choice == 3:
                self.addon.openSettings()
        except UpdateError as exc:
            log(str(exc), xbmc.LOGERROR)
            self.dialog.ok(BUILD_NAME, str(exc))
        except Exception as exc:
            log('Unexpected error: {}'.format(exc), xbmc.LOGERROR)
            self.dialog.ok(BUILD_NAME, 'Update failed: {}'.format(exc))
