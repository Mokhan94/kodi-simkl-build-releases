import xbmc
import xbmcaddon

from resources.lib.updater import Updater


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    addon = xbmcaddon.Addon()
    updater = Updater()
    released = updater.cleanup_update_storage()
    if released:
        xbmc.log(
            '[Mokhan Build Updater] Removed legacy updater downloads/backups.',
            xbmc.LOGINFO)
    updater.activate_build()
    if addon.getSettingBool('check_startup') and not monitor.waitForAbort(15):
        updater.check_background()
