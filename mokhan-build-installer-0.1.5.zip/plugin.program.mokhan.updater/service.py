import xbmc
import xbmcaddon

from resources.lib.updater import Updater


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    addon = xbmcaddon.Addon()
    Updater().activate_build()
    if addon.getSettingBool('check_startup') and not monitor.waitForAbort(15):
        Updater().check_background()
