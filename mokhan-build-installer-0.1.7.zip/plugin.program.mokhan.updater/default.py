import sys

import xbmcplugin

from resources.lib.updater import Updater


if __name__ == '__main__':
    try:
        Updater().run_interactive()
    finally:
        if len(sys.argv) > 1:
            try:
                xbmcplugin.endOfDirectory(
                    int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            except (TypeError, ValueError, RuntimeError):
                pass
